package server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;

import java.nio.charset.Charset;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.SignatureException;

import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import logging.LogSetup;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import common.CommonCrypto;
import common.Settings;

public class Server {
	
	public static String SERVER_CERT_PATH = "";
	public static String SERVER_PRIVKEY_PATH = "";
	
	int listenPort;
	boolean requireClientAuth;
	boolean listening;
	
	Logger logger = null;
	public static X509Certificate serverCertificate = null;
	public static X509Certificate caCertificate = null;
	private static PrivateKey serverPrivateKey;
	private ArrayList<X509Certificate> trustedCAs;
	
	/**
	 * Create a new Server, listening on specified port and serving payload file to clients using miniSSL protocol.
	 * @param listenPort remote port for server to listen on
	 * @param serverCertPath path to the servers certificate file
	 * @param serverPrivKeyPath path to the servers private key file
	 * @param payloadPath path to the payload file
	 * @param simple true if simple authentication should be used
	 */
	public Server(int listenPort, String serverCertificatePath, String serverPrivKeyPath, boolean requireClientAuth) {
		Server.SERVER_CERT_PATH = serverCertificatePath;
		Server.SERVER_PRIVKEY_PATH = serverPrivKeyPath;
		this.listenPort = listenPort;
		this.requireClientAuth = requireClientAuth;
		
		initLog();
		try {
			trustedCAs = CommonCrypto.loadTrustStore();
		} catch (CertificateException e) {
			logger.error("Unable to load Trust Store: " + e.getMessage() + "\nServer Application terminated.");
			System.exit(1);
		} catch (Exception e) {
			logger.error("Unable to load Trust Store: " + e.getMessage() + "\nServer Application terminated.");
			System.exit(1);
		}
		logger.info("---List of trusted CAs---");
		for (X509Certificate cert : trustedCAs) {
			logger.info(cert.getSubjectX500Principal().getName());
		}
		
		if (logger == null) {
			System.out.println("Unable to initialize logging for server. Application terminated.");
			System.exit(1);
		}
		
		/* Try importing Server Certificate */
		try {
			createServerCertificate(serverCertificatePath);
		} catch (CertificateException e) {
			throw new IllegalArgumentException("Unable to create Server X.509 Certificate from file: " + serverCertificatePath);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Server X.509 Certificate file not found at: " + serverCertificatePath);
		}
		
		/* Try to import CA Certificate */
		try {
			importCACertificate(Settings.getCACertPath());
		} catch (CertificateException e) {
			logger.error("Unable to import CA Certificate from file: " + Settings.getCACertPath() + ", or Certificate invalid.\nReason: " + e.getMessage() + "\nServer Exiting.");
			System.exit(1);
		}

		try {
			Server.serverPrivateKey = CommonCrypto.loadPrivateKey(serverPrivKeyPath, Charset.forName(Settings.CHARSET));
		} catch (FileNotFoundException e) {
			logger.error("Servers private key file not found at: " + serverPrivKeyPath + "\nServer Application terminated.");
			System.exit(1);
		}catch (IOException e) {
			logger.error("Unable to read this Servers private key from file: " + serverPrivKeyPath +
					",\nReason: " + e.getMessage() + "\nServer Application terminated.");
			System.exit(1);
		} catch (InvalidKeySpecException e) {
			logger.error("Unable to read this Servers private key from file: " + serverPrivKeyPath +
					",\nReason: " + e.getMessage() + "\nPlease make sure the private key file is in ENCRYPTED PKCS8 Format.\n" +
							"To convert an unencrypted PEM key with openssl use the following command:\n" +
							"openssl pkcs8 -topk8 -nocrypt -inform PEM -outform DER -in inputKey.key.pem -out pkcs8OutputKey.key.pem\n" +
							"Server Application terminated.");
			System.exit(1);
		} catch (NoSuchAlgorithmException e) {
			logger.error("Unable to read this Servers private key from file: " + serverPrivKeyPath +
					",\nReason: " + e.getMessage() + "\nServer Application terminated.");
			System.exit(1);
		}
		
		this.listening = true;
	}
	
	
	private void createServerCertificate(String serverCertificatePath) throws CertificateException, FileNotFoundException {
		File certificateFile = new File(serverCertificatePath);
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		Server.serverCertificate = (X509Certificate) certFactory.generateCertificate(new FileInputStream(certificateFile));
	}
	
	
	public void importCACertificate(String path) throws CertificateException {
		try {
			Server.caCertificate = CommonCrypto.importCACertificate(path);
		} catch (CertificateException e) {
			logger.error("Unable to create X.509 CA Certificate from file: " + path + 
					"\nReason: " + e.getMessage() + 
					"\nServer Application terminated.");
			System.exit(1);
		}
		
		try {
			if (!CommonCrypto.isCATrusted(Server.caCertificate, this.trustedCAs)) {
				logger.error("CA Certificate: " + Server.caCertificate.getSubjectX500Principal() + " is not a trusted CA.\nServer Application terminated.");				
				System.exit(1);
			}
		} catch (InvalidKeyException e) {
			throw new CertificateException("Unable to import CA Certificate: " + e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			throw new CertificateException("Unable to import CA Certificate: " + e.getMessage());
		} catch (NoSuchProviderException e) {
			throw new CertificateException("Unable to import CA Certificate: " + e.getMessage());
		} catch (SignatureException e) {
			throw new CertificateException("Unable to import CA Certificate: " + e.getMessage());
		}
	}
	
	
	public void process() {
		
		logger.info("listening at port: " + listenPort);
		
		try (ServerSocket serverSocket = new ServerSocket(listenPort)) {
			while (listening) {
				new Thread(new ClientConnection(serverSocket.accept(), requireClientAuth)).start();
			}
		} catch (IOException e) {
	        logger.error("Exception caught while listening on ServerSocket at port "
	            + listenPort + ". Message: " + e.getMessage());
		}
	}
	
	
	public static PrivateKey getPrivateKey() {
		return serverPrivateKey;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
        if (args.length != 5) {
            System.err.println("Usage: java Server <listen_port> <servercert> <serverprivkey> <{SimpleAuth, ClientAuth}> <payload-file>");
            System.exit(1);
        }
        
        boolean clientAuth = false;
        int listenPort = Integer.parseInt(args[0]);
        
        String serverCertPath = args[1];
        String serverPrivKeyPath = args[2];
        String payloadFile = args[3];
        
        if (args[3].equals("SimpleAuth"))
        	clientAuth = false;
        else if (args[3].equals("ClientAuth"))
        	clientAuth = true;
        else {
            System.err.println("Invalid Auth Mode. Usage: java Server <listen_port> <servercert> <serverprivkey> <{SimpleAuth, ClientAuth}> <payload-file>");
            System.exit(1);
        }
        
        Settings.USE_CLIENT_AUTH = clientAuth;
        Settings.PAYLOAD_FILE = payloadFile;
        
        Server server = new Server(listenPort, serverCertPath, serverPrivKeyPath, clientAuth);
		// Server server = new Server(50000, "certs/minissl-server.pem", "certs/minissl-server.key.pem", "payload", Settings.USE_CLIENT_AUTH);
        server.process();
	}

	
	public void initLog() {
		LogSetup ls = new LogSetup("logs\\server.log", "Server", Level.ALL);
		this.logger = ls.getLogger();
	}
}
