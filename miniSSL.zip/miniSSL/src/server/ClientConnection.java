package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;

import logging.LogSetup;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import common.ClientInitMessage;
import common.ClientKeyExchangeMessage;
import common.CommandGET;
import common.CommonCrypto;
import common.ErrorMessage;
import common.EncryptedFileMessage;
import common.Message;
import common.MessageType;
import common.ServerAuthConfirmationMessage;
import common.ServerInitMessage;
import common.SessionException;
import common.SessionInfo;
import common.Settings;

/**
 * Represents a connection between server & client.
 * @author Elias Tatros
 *
 */
public class ClientConnection implements Runnable {
	
	Socket localSocket;
	Logger logger;
	ObjectOutputStream out;
	ObjectInputStream in;
	SessionInfo session;
	
	public ClientConnection (Socket localSocket, boolean requireClientAuth) {
		this.localSocket = localSocket;
		
		initLog();
		session = new SessionInfo();
		session.setClientAuthRequired(requireClientAuth);
		
		if (logger == null) {
			System.out.println("Unable to initialize logging for Client Connection from " + 
					localSocket.getInetAddress() + " at port " + localSocket.getPort() + ". Connection terminated.");
			System.exit(1);
		}
		
		/* Try to import CA Certificate */
		try {
			session.setCACertificate(CommonCrypto.importCACertificate(Settings.getCACertPath()));
		} catch (CertificateException e) {
			logger.error("Unable to import CA Certificate from file: " + Settings.getCACertPath() + ", or Certificate invalid.\nReason: " + e.getMessage() + "\nClient Application Exiting.");
			System.exit(1);
		}
		
		logger.info("Accepted New Client Connection from " + localSocket.getInetAddress() + " at port " + localSocket.getPort());
		
		session.setServerIP(localSocket.getLocalAddress().getHostAddress());
		session.setClientIP(localSocket.getInetAddress().getHostAddress());
		session.setLocalPort(localSocket.getLocalPort());
		session.setRemotePort(localSocket.getPort());
	}
	
	public String receiveString() throws IOException {
		if (in != null) {
			try {
				Object input =  in.readObject();
				if (input instanceof String) {
					logger.info("RECEIVE << " + input);
					return (String)input;
				} else {
					throw new IOException("Received Object was not of the expected type. Expected <String>, Received <" + input.getClass() + ">");
				}
			} catch (ClassNotFoundException e) {
				throw new IOException("Received Object was not of the expected type. Expected <String>, Received <UnknownType>");
			}
		} else {
			throw new ConnectException("Unable to receive message. Not connected to a Client.");
		}
	}
	
	
	/**
	 * Receive the first client message during the handshake.
	 * @return ClientInitMessage
	 * @throws IOException
	 */
	public ClientInitMessage receiveClientInit() throws IOException {
		if (in != null) {
			try {
				Object input =  in.readObject();
				if (input instanceof ClientInitMessage) {
					logger.info("RECEIVE << " + input);
					return (ClientInitMessage)input;
				} else {
					throw new IOException("Received Object was not of the expected type. Expected <ClientInitMessage>, Received <" + input.getClass() + ">");
				}
			} catch (ClassNotFoundException e) {
				throw new IOException("Received Object was not of the expected type. Expected <ClientInitMessage>, Received <UnknownType>");
			}
		} else {
			throw new ConnectException("Unable to receive message. Not connected to a Client.");
		}
	}
	
	
	/**
	 * Receive the second message from client during handshake.
	 * @return ClientKeyExchangeMessage
	 * @throws IOException
	 */
	public ClientKeyExchangeMessage receiveClientKeyExchangeMessage() throws IOException {
		if (in != null) {
			try {
				Object input =  in.readObject();
				if (input instanceof ClientKeyExchangeMessage) {
					logger.info("RECEIVE << " + input);
					return (ClientKeyExchangeMessage)input;
				} else {
					throw new IOException("Received Object was not of the expected type. Expected <ClientKeyExchangeMessage>, Received <" + input.getClass() + ">");
				}
			} catch (ClassNotFoundException e) {
				throw new IOException("Received Object was not of the expected type. Expected <ClientKeyExchangeMessage>, Received <UnknownType>");
			}
		} else {
			throw new ConnectException("Unable to receive message. Not connected to a Client.");
		}
	}
	
	
	/**
	 * Send a serializable object over socket output stream
	 * @param obj
	 * @throws IOException
	 */
	public void send(Serializable obj) throws IOException {
		if (out != null) {
			out.writeObject(obj);
			out.flush();
			logger.info("SEND >> " + obj.toString());
		} else {
			throw new ConnectException("Unable to transmit message. Not connected to the Server.\n" +
					"Message: " + obj.toString());
		}
	}
	
	
	/**
	 * General receive method
	 * @return Message received Message
	 * @throws IOException
	 */
	public Message receive() throws IOException {
		if (in != null) {
			try {
				Object input =  in.readObject();
				
				if (input instanceof ClientInitMessage) {
					logger.info("RECEIVE << " + input);
					return (ClientInitMessage)input;
					
				} else if (input instanceof ClientKeyExchangeMessage) {
					logger.info("RECEIVE << " + input);
					return (ClientKeyExchangeMessage)input;
					
				} else if (input instanceof CommandGET) {
					logger.info("RECEIVE << " + input);
					return (CommandGET)input;	
					
				} else if (input instanceof ErrorMessage) {
					logger.info("RECEIVE << " + input);
					return (ErrorMessage)input;
					
				} else if (input instanceof ServerAuthConfirmationMessage) {
					logger.info("RECEIVE << " + input);
					return (ServerAuthConfirmationMessage)input;
					
				} else if (input instanceof ServerInitMessage) {
					logger.info("RECEIVE << " + input);
					return (ServerInitMessage)input;
				} else {
					throw new IOException("Received Object is not a valid Message. Expected <Message>, Received <" + input.getClass() + ">");
				}
			} catch (ClassNotFoundException e) {
				throw new IOException("Received Object was not of the expected type. Expected <Message>, Received <UnknownType>");
			}
		} else {
			throw new ConnectException("Unable to receive message. Not connected to a Client.");
		}
	}
	
	
	/**
	 * Main processing method of this connection
	 */
	@Override
	public void run() {
		try (
				ObjectOutputStream out = new ObjectOutputStream(localSocket.getOutputStream());
				ObjectInputStream in = new ObjectInputStream(localSocket.getInputStream());
        ) {
			try {
				this.out = out;
				this.in = in;
				
				// Expect ClientInit
				Message message = receive();
				if (!verifyMessageType(message, MessageType.ClientInitMessage))
					throw new Exception("Invalid Message received.");
				
				ClientInitMessage clientInitMessage = (ClientInitMessage) message;
				session.setClientNonce(clientInitMessage.getNonce());	
				// Send ServerInit
				ServerInitMessage serverInitMessage = new ServerInitMessage(Settings.TRANSFER_ENCRYPTION, Server.serverCertificate, session.isClientAuthRequired());
				session.setServerNonce(serverInitMessage.getNonce());
				session.setServerCertificate(serverInitMessage.getCertificate());
				send(serverInitMessage);
				
				// Expect ClientKeyExchangeMessage
				message = receive();
				if (!verifyMessageType(message, MessageType.ClientKeyExchangeMessage))
					throw new Exception("Invalid Message received.");
				
				ClientKeyExchangeMessage clientKeyExchangeMessage = (ClientKeyExchangeMessage) message;
				session.setClientCertificate(clientKeyExchangeMessage.getClientCertificate());
				session.setEncryptedSecret(clientKeyExchangeMessage.getEncryptedSecret());	
				
				// Decrypt the master secret
				session.setMasterSecret(CommonCrypto.decryptRSA(clientKeyExchangeMessage.getEncryptedSecret(), Settings.ALGORITHM_ENCRYPTION, Server.getPrivateKey()));
				logger.debug("RECEIVED & DECRYPTED MASTER SECRET (p): " + new String(session.getMasterSecret(), Settings.CHARSET));
	
				// Generate session keys for encryption and mac from received master secret
				try {
					session.setEncKey(CommonCrypto.generateSessionKey(Settings.ALGORITHM_HASHING, session.getMasterSecret(), session.getClientNonce(), session.getServerNonce(), new String("00000000").getBytes(Settings.CHARSET)));
					session.setMacKey(CommonCrypto.generateSessionKey(Settings.ALGORITHM_HASHING, session.getMasterSecret(), session.getClientNonce(), session.getServerNonce(), new String("11111111").getBytes(Settings.CHARSET)));
				} catch (InvalidKeyException e) {
					throw new Exception ("Unable to generate Session keys, Invalid key: " + Settings.ALGORITHM_ENCRYPTION + ",\nMessage: " + e.getMessage()+ "\nConnection terminated.");
				} catch (NoSuchAlgorithmException e) {
					throw new Exception ("Unable to generate Session keys, Invalid cipher: " + Settings.ALGORITHM_ENCRYPTION + ",\nMessage: " + e.getMessage()+ "\nConnection terminated.");
				}
				
				// Authenticate Client
				if (session.isClientAuthRequired()) {
					CommonCrypto.verifyCertificate(session.getClientCertificate(), session.getCACertificate());
					System.out.println(session.getClientCertificate());
					logger.info("Client Certificate verified by CA.");
					
					try {
						byte[] decryptedSignature = CommonCrypto.decryptRSA(clientKeyExchangeMessage.getSignature(), Settings.ALGORITHM_ENCRYPTION, session.getClientCertificate().getPublicKey());
						byte[] sigContent = CommonCrypto.concatenateByteArray(session.getServerNonce(), session.getEncryptedSecret());
						byte[] sigContentHash = CommonCrypto.generateHash(Settings.ALGORITHM_HASHING, session.getMacKey(), sigContent);
	
						
						
						if (CommonCrypto.isByteArrayEqual(sigContentHash, decryptedSignature)) {
							logger.info("Client Signature verified on Server Nonce and encrypted master secret.");
						} else {
							throw new SignatureException("Client Signature invalid. Signature hash did not match.");
						}
					} catch (Exception e) {
						//logger.error("Client Signature invalid or unable to verify Signature. Message: " + e.getMessage() + "\nSession terminated.");
						throw new SignatureException("Client Signature invalid or unable to verify Signature. Message: " + e.getMessage() + "\nSession terminated.");
					}
				}
				
				// Compute session hash from session information
				try {
					session.setSecureSessionHash(CommonCrypto.generateSessionHash(Settings.ALGORITHM_HASHING, session.getMacKey(), session.getClientNonce(), session.getServerNonce(), session.getServerCertificate().getEncoded(), session.isClientAuthRequired()));
				} catch (InvalidKeyException e) {
					throw new Exception ("Unable to generate Session Hash, Invalid key: " +  Settings.ALGORITHM_HASHING + ",\nMessage: " + e.getMessage()+ "\nConnection terminated.");
				} catch (CertificateEncodingException e) {
					throw new Exception ("Unable to generate Session Hash, Invalid Certificate Encoding: " + Settings.ALGORITHM_HASHING + ",\nMessage: " + e.getMessage()+ "\nConnection terminated.");
				} catch (NoSuchAlgorithmException e) {
					throw new Exception ("Unable to generate Session Hash, Invalid Algorithm: " + Settings.ALGORITHM_HASHING + ",\nMessage: " + e.getMessage()+ "\nConnection terminated.");
				}
			
				// Compare generated session hash with session hash received from client
				if (!(CommonCrypto.isByteArrayEqual(session.getSecureSessionHash(), clientKeyExchangeMessage.getSecureSessionHash()))) {
					throw new Exception("Session Information Mismatch. Session Hash received from Client did not match Session Hash computed on Server.");
				} else {
					logger.info("Successfully compared Session Information. Session Hash on Server matches Hash received from Client.");
				}
				
				// Generate Auth Confirmation Hash & send to client
				if (session.isClientAuthRequired())
					session.setSecureConfirmationHash(CommonCrypto.generateConfirmationHash(Settings.ALGORITHM_HASHING, session.getMacKey(), session.getEncryptedSecret(), session.getSecureSessionHash(), session.getClientCertificate()));
				else
					session.setSecureConfirmationHash(CommonCrypto.generateConfirmationHash(Settings.ALGORITHM_HASHING, session.getMacKey(), session.getEncryptedSecret(), session.getSecureSessionHash()));
				ServerAuthConfirmationMessage serverAuthConfirmationMessage = new ServerAuthConfirmationMessage(session.getSecureConfirmationHash(), session.isClientAuthRequired());
				send (serverAuthConfirmationMessage);
				
				// Validate Session
				session.validateSession();
				logger.info("Session validated. Handshake is complete.");
				
				// Expect GET from Client
				message = receive();
				if (!verifyMessageType(message, MessageType.CommandGET))
					throw new Exception("Invalid Message received.");
				
				CommandGET get = (CommandGET) message;
				logger.debug("---BEGIN AES-" + session.getEncKey().getEncoded().length * 8 + " KEY---");
				logger.debug(new String(session.getEncKey().getEncoded(), Settings.CHARSET));
				logger.debug("---END AES-" + session.getEncKey().getEncoded().length * 8 + " KEY---");
				
				EncryptedFileMessage fileMessage = new EncryptedFileMessage(get.getFilename(), Settings.TRANSFER_ENCRYPTION, session.getEncKey());
				
				// Send encrypted file to client
				send(fileMessage);
				
			} catch (Exception e) {
				//e.printStackTrace();
				
	        	if (e instanceof SocketException) {
	        		logger.error("Unable to use Socket. Reason: " + e.getMessage() + ". Connection thread terminated.");
	        	} else if (e instanceof SessionException) {
	        		logger.error("Session failed to validate: " + e.getMessage() + ".\nConnection terminated.");
	        	} else if (e instanceof IllegalArgumentException) {
	        		logger.error("Wrong Session Argument: " + e.getMessage() + ".\nConnection terminated.");
	        	}
	        	
	        	if (e.getMessage() != null) {
	        		logger.error("-- Connection terminated due to an error --\n" + "> " + e.getMessage());
	        		send (new ErrorMessage("-- Connection terminated due to an error --\n" + "> " + e.getMessage()));
	        	} else { 
	        		logger.error("-- Connection terminated due to an error --");
	        	}
			}
			
			
        } catch (java.io.EOFException e) {
        	logger.warn("Connection terminated by Client.");
        	return;
        } catch (IOException e) {
        	if (e instanceof SocketException) {
        		logger.error("Unable to use Socket. Reason: " + e.getMessage() + ". Connection thread terminated.");
        		System.exit(1);
        	}
        	
            logger.error("IOException occured while listening for Connection on port "
                + localSocket + ". Message: " + e.getMessage() + ", Cause: " + e.getCause() + ", Type: " + e.getClass());
        }
	}
	
	
	/**
	 * Verifies that a given message is of a specific type
	 * @param message message to verify
	 * @param expectedType the expected MessageType
	 * @return true if message is of specified type, false otherwise
	 * @throws Exception in case of an error
	 */
	public boolean verifyMessageType(Message message, MessageType expectedType) throws Exception {
		if (message.getType().equals(expectedType)) {
			return true;
		} else if (message.getType().equals("ErrorMessage")) {
			ErrorMessage errorMessage = (ErrorMessage) message;
			throw new Exception("Received Error Message from Client: " + errorMessage.getMessage());
		} else {
			throw new Exception("Received unexpected Message from Client. Type: " + message.getType());
		}
	}
	
	
	/**
	 * Initialize log4j logging
	 * Clients log file in logs/client.log
	 */
	public void initLog() {
		LogSetup ls = new LogSetup("logs\\connections.log", "Connection @" + this.localSocket.getPort(), Level.ALL);
		this.logger = ls.getLogger();
	}
}
