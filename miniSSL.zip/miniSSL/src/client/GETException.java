package client;

public class GETException extends Exception {

	private static final long serialVersionUID = -2873311306981309038L;

	public GETException(String message) {
		super(message);
	}
}
