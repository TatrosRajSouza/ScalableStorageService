package client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import logging.LogSetup;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import common.ClientInitMessage;
import common.ClientKeyExchangeMessage;
import common.CommandGET;
import common.CommonCrypto;
import common.ErrorMessage;
import common.EncryptedFileMessage;
import common.HandshakeException;
import common.Message;
import common.MessageType;
import common.ServerAuthConfirmationMessage;
import common.ServerInitMessage;
import common.SessionException;
import common.SessionInfo;
import common.Settings;


/**
 * Implementation of the minissl-client. 
 * 
 * The Client is given a destinationIP and Port, which it tries to connect to.
 * Furthermore the client expects a path to the client certificate and to its private key in pkcs 8 format.
 * Use "openssl pkcs8 -topk8 -nocrypt -inform PEM -outform DER -in inputKey.key.pem -out pkcs8OutputKey.key.pem"
 * to convert a given key to this format. (Note: The keys provided with this implementation are already converted.)
 * 
 * The clients log file can be found in logs/client.log
 * The client trusts CA certificates from its trustStore (certs/trustStore).
 * 
 * @author Elias Tatros
 *
 */
public class Client {
	
	private String destinationIP = "";
	private int destinationPort = -1;
	
	private ObjectOutputStream out = null;
	private ObjectInputStream in = null;
	
	private Logger logger = null;
	private PrivateKey clientPrivateKey;
	private SessionInfo session;
	private ArrayList<X509Certificate> trustedCAs;
	
	/**
	 * Create a new mini-SSL client
	 * @param destinationIP IP of remote server, which we should connect to
	 * @param destinationPort remote port server is listening on
	 * @param clientCertPath Path to Certificate file
	 * @param clientPrivKeyPath Path to Private Key file
	 */
	public Client (String destinationIP, int destinationPort, String clientCertPath, String clientPrivKeyPath) {
		this.destinationIP = destinationIP;
		this.destinationPort = destinationPort;
		
		/* Initialize logging */
		initLog();
		
		/* Load trusted CAs from trust store */
		try {
			trustedCAs = CommonCrypto.loadTrustStore();
		} catch (CertificateException e) {
			logger.error("Unable to load Trust Store: " + e.getMessage() + "\nClient Application terminated.");
			System.exit(1);
		} catch (Exception e) {
			logger.error("Unable to load Trust Store: " + e.getMessage() + "\nServer Application terminated.");
			System.exit(1);
		}
		logger.info("---List of trusted CAs---");
		for (X509Certificate cert : trustedCAs) {
			logger.info(cert.getSubjectX500Principal().getName());
		}
		
		/* Create new session */
		session = new SessionInfo();
		
		if (logger == null) {
			System.out.println("Unable to initialize logging for client. Application terminated.");
			System.exit(1);
		}
		
		/* 
		 * Try to import clients private key
		 * Please make sure key is in pkcs 8 format.
		 * For conversion you can use:
		 * "openssl pkcs8 -topk8 -nocrypt -inform PEM -outform DER -in inputKey.key.pem -out pkcs8OutputKey.key.pem"
		 */
		try {
			this.clientPrivateKey = CommonCrypto.loadPrivateKey(clientPrivKeyPath, Charset.forName(Settings.CHARSET));
		} catch (UnsupportedCharsetException e) {
			logger.error("Cannot read Clients private key at: " + clientPrivKeyPath + ",\nbecause the Charset " + Settings.CHARSET + " is not supported.\nClient Application terminated.");
			System.exit(1);
		} catch (FileNotFoundException e) {
			logger.error("Clients private key file not found at: " + clientPrivKeyPath + "\nClient Application terminated.");
			System.exit(1);
		}catch (IOException e) {
			logger.error("Unable to read this clients private key from file: " + clientPrivKeyPath +
					",\nReason: " + e.getMessage() + "\nClient Application terminated.");
			System.exit(1);
		} catch (InvalidKeySpecException e) {
			logger.error("Unable to read this clients private key from file: " + clientPrivKeyPath +
					",\nReason: " + e.getMessage() + "\nPlease make sure the private key file is in PKCS8 DER Format.\n" +
							"To convert an unencrypted PEM key with openssl use the following command:\n" +
							"openssl pkcs8 -topk8 -nocrypt -inform PEM -outform DER -in inputKey.key.pem -out pkcs8OutputKey.key.pem\n" +
							"Client Application terminated.");
			System.exit(1);
		} catch (NoSuchAlgorithmException e) {
			logger.error("Unable to read this clients private key from file: " + clientPrivKeyPath +
					",\nReason: " + e.getMessage() + "\nClient Application terminated.");
			System.exit(1);
		}
		
		/* Try to import CA Certificate */
		try {
			session.setCACertificate(CommonCrypto.importCACertificate(Settings.getCACertPath()));
			if (!CommonCrypto.isCATrusted(session.getCACertificate(), this.trustedCAs)) {
				logger.error("CA Certificate: " + session.getCACertificate().getSubjectX500Principal() + " is not a trusted CA.\nClient Application terminated.");				
				System.exit(1);
			}
		} catch (CertificateException e) {
			logger.error("Unable to import CA Certificate from file: " + Settings.getCACertPath() + ", or Certificate invalid.\nReason: " + e.getMessage() + "\nClient Application Exiting.");
			System.exit(1);
		} catch (InvalidKeyException e) {
			logger.error("Unable to import CA Certificate: " + e.getMessage() + ".\nClient Application terminated.");
			System.exit(1);
		} catch (NoSuchAlgorithmException e) {
			logger.error("Unable to import CA Certificate: " + e.getMessage() + ".\nClient Application terminated.");
			System.exit(1);
		} catch (NoSuchProviderException e) {
			logger.error("Unable to import CA Certificate: " + e.getMessage() + ".\nClient Application terminated.");
			System.exit(1);
		} catch (SignatureException e) {
			logger.error("Unable to import CA Certificate: " + e.getMessage() + ".\nClient Application terminated.");
			System.exit(1);
		}
		
		/* Try to import Client Certificate */
		try {
			importClientCertificate(clientCertPath);
		} catch (CertificateException e) {
			throw new IllegalArgumentException("Unable to create X.509 Certificate from file: " + clientCertPath);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("X.509 Certificate file not found at: " + clientCertPath);
		}
	}

	/**
	 * Imports the client certificate from the specified path
	 * @param path Path to the client certificate file
	 * @throws CertificateException
	 * @throws FileNotFoundException
	 */
	public void importClientCertificate(String path) throws CertificateException, FileNotFoundException {
		File certificateFile = new File(path);
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		X509Certificate clientCert = (X509Certificate) certFactory.generateCertificate(new FileInputStream(certificateFile));
		session.setClientCertificate(clientCert);
	}
	
	
	/**
	 * Send serializable java object over socket output stream
	 * @param obj A serializable java object
	 * @throws IOException
	 */
	public void send(Serializable obj) throws IOException {
		if (obj == null) {
			throw new IOException("Tried to send null Object.");
		}
		
		if (out != null) {
			out.writeObject(obj);
			out.flush();
			logger.info("SEND >> " + obj.toString());
		} else {
			throw new ConnectException("Unable to transmit message. Not connected to the Server.\n" +
					"Message: " + obj.toString());
		}
	}
	
	
	/**
	 * Receive the first server message during handshake (ServerInit) over socket input stream. 
	 * @return ServerInitMessage
	 * @throws IOException In case of connection failure, error message or unexpected message
	 */
	public ServerInitMessage receiveServerInit() throws IOException {
		if (in != null) {
			try {
				Object input =  in.readObject();
				if (input instanceof ServerInitMessage) {
					logger.info("RECEIVE << " + input);
					return (ServerInitMessage)input;
				} else if (input instanceof ErrorMessage) {
					ErrorMessage error = (ErrorMessage) input;
					logger.info("RECEIVE << " + error);
					throw new IOException("Connection closed by Server due to error. Message: " + error.getMessage());
				} else {
					throw new IOException("Received Object was not of the expected type. Expected <ServerInitMessage>, Received <" + input.getClass() + ">");
				}
			} catch (ClassNotFoundException e) {
				throw new IOException("Received Object was not of the expected type. Expected <ServerInitMessage>, Received <UnknownType>");
			}
		} else {
			throw new ConnectException("Unable to receive message. Not connected to a Client.");
		}
	}
	
	
	/**
	 * Receive the second server message during handshake (ServerAuthConfirmation) over socket input stream
	 * @return ServerAuthConfirmationmessage
	 * @throws IOException In case of connection failure, error message or unexpected message
	 */
	public ServerAuthConfirmationMessage receiveServerAuthConfirmation() throws IOException {
		if (in != null) {
			try {
				Object input =  in.readObject();
				if (input instanceof ServerAuthConfirmationMessage) {
					logger.info("RECEIVE << " + input);
					return (ServerAuthConfirmationMessage)input;
				} else if (input instanceof ErrorMessage) {
					ErrorMessage error = (ErrorMessage) input;
					logger.info("RECEIVE << " + error);
					throw new IOException("Connection closed by Server due to error. Message: " + error.getMessage());
				} else {
					throw new IOException("Received Object was not of the expected type. Expected <ServerAuthConfirmationMessage>, Received <" + input.getClass() + ">");
				}
			} catch (ClassNotFoundException e) {
				throw new IOException("Received Object was not of the expected type. Expected <ServerAuthConfirmationMessage>, Received <UnknownType>");
			}
		} else {
			throw new ConnectException("Unable to receive message. Not connected to a Client.");
		}
	}
	
	
	/**
	 * Generate random bytes for pre-master secret
	 * @param numBytes number of bytes to generate
	 * @return random bytes of specified length
	 */
	private byte[] generateMasterSecret(int numBytes) {
		byte[] p = new byte[numBytes];
		
		Random rand = new Random();
		rand.nextBytes(p);
		
		return p;
	}
	
	
	/**
	 * General receive function 
	 * @return Message the received Message
	 * @throws IOException In case of invalid message / data
	 */
	public Message receive() throws IOException {
		if (in != null) {
			try {
				Object input =  in.readObject();
				
				if (input instanceof ErrorMessage) {
					ErrorMessage error = (ErrorMessage) input;
					logger.info("RECEIVE << " + error);
					throw new IOException("Connection closed by Server due to error. Message: " + error.getMessage() + "\nClient Application terminated.");
				} else if (input instanceof EncryptedFileMessage) {
					logger.info("RECEIVE << " + input);
					return (EncryptedFileMessage)input;
				} else if (input instanceof ClientInitMessage) {
					logger.info("RECEIVE << " + input);
					return (ClientInitMessage)input;
					
				} else if (input instanceof ClientKeyExchangeMessage) {
					logger.info("RECEIVE << " + input);
					return (ClientKeyExchangeMessage)input;
					
				} else if (input instanceof CommandGET) {
					logger.info("RECEIVE << " + input);
					return (CommandGET)input;	
					
				} else if (input instanceof ErrorMessage) {
					logger.info("RECEIVE << " + input);
					return (ErrorMessage)input;
					
				} else if (input instanceof ServerAuthConfirmationMessage) {
					logger.info("RECEIVE << " + input);
					return (ServerAuthConfirmationMessage)input;
					
				} else if (input instanceof ServerInitMessage) {
					logger.info("RECEIVE << " + input);
					return (ServerInitMessage)input;
				} else {
					throw new IOException("Received Object is not a valid Message. Expected <T implements Message>, Received <" + input.getClass() + ">");
				}
			} catch (ClassNotFoundException e) {
				throw new IOException("Received Object was not of the expected type. Expected <T implements Message>, Received <UnknownType>");
			}
		} else {
			throw new ConnectException("Unable to receive message. Not connected to a Client.");
		}
	}
	
	
	/**
	 * Verifies that a given message is of a specific type
	 * @param message message to verify
	 * @param expectedType the expected MessageType
	 * @return true if message is of specified type, false otherwise
	 * @throws Exception in case of an error
	 */
	public boolean verifyMessageType(Message message, MessageType expectedType) throws Exception {
		if (message.getType().equals(expectedType)) {
			return true;
		} else if (message.getType().equals("ErrorMessage")) {
			ErrorMessage errorMessage = (ErrorMessage) message;
			throw new Exception("Received Error Message from Server: " + errorMessage.getMessage());
		} else {
			throw new Exception("Received unexpected Message from Server. Type: " + message.getType());
		}
	}
	
	
	/**
	 * Write a file to the clients files folder
	 * @param filename name of the file
	 * @param fileContents contents of the file
	 * @throws IOException in case of an error
	 */
	private void writeFile(String filename, byte[] fileContents) throws IOException {
		logger.info("Writing file \"" + filename + "\" to folder: " + Settings.CLIENT_FILES);
		String filepath = Settings.CLIENT_FILES + "/" + filename;
		File f = new File(filepath);
	
		f.createNewFile();
		Files.write(f.toPath(), fileContents, StandardOpenOption.WRITE);
	}
	
	
	/**
	 * Main processing function for the client 
	 * @throws Exception
	 */
	public void process() throws Exception {
		
		logger.info("Connecting to server address: " + destinationIP + ":" + destinationPort);
		
		/* Use try-with-resource statement for automatic resource management */
		try (
			Socket clientSocket = new Socket(destinationIP, destinationPort);
			ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
			
			BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))
				
			) { 
				this.out = out;
				this.in = in;
				
				performHandshake(clientSocket); // perform the handshake
				secureGet(Settings.PAYLOAD_FILE); // download the file
				
	        } catch (HandshakeException e) {
	        	logger.error("---Error during Handshake---\n" + e.getMessage() + "\nClient Application terminated.");
	        	System.exit(1);
	        } catch (GETException e) {
	        	logger.error("---Error during secure GET---\n" + e.getMessage() + "\nClient Application terminated.");
	        	System.exit(1);
	        } catch (UnknownHostException e) {
	            logger.error("Cannot resolve " + destinationIP);
	            System.exit(1);
	        } catch (ConnectException e) {
	        	logger.error("ConnectException. Unable to connect to " + destinationIP + " on port " + destinationPort + ".\n" +
	        			"Message: " + e.getMessage() + "\n" +
	        			"Please make sure the Server is running at specified address and port.");
	            System.exit(1);
	        } catch (IOException e) {
	        	logger.error("I/O lost. Connection to " + destinationIP + " closed.");
	            System.exit(1);
	        } catch (Exception e) {
	        	logger.error(e.getMessage() + "\nClient Application terminated.");
	        	System.exit(1);
	        } finally {
	        	logger.info("All actions complete. Connection Closed. Client application exiting.");
	        }
	}
	
	
	/**
	 * Download the specified file from the Server
	 * @param filename name of the file
	 * @throws Exception
	 */
	public void secureGet(String filename) throws Exception {
		if (!session.isValid())
			throw new GETException("Cannot perform GET " + filename + ", because the session is not valid.");
		
		try {
			send(new CommandGET(filename));
			Message message = receive();
			if (!verifyMessageType(message, MessageType.EncryptedFileMessage))
				throw new GETException("Invalid Message received.");
			
			EncryptedFileMessage fileMessage = (EncryptedFileMessage) message;
			
			/* Decrypt contents */
			byte[] plainMessage = CommonCrypto.decryptAES(fileMessage.getEncryptedMessage(), fileMessage.getAlgorithm(), session.getEncKey(), fileMessage.getIV());
			logger.info("Successfully decrypted message using " + fileMessage.getAlgorithm());
			logger.info("---BEGIN DECRYPTED MESSAGE---");
			logger.info(new String(plainMessage, Settings.CHARSET));
			logger.info("---END DECRYPTED MESSAGE---");
			logger.info("GET Complete.");
			
			writeFile(filename, plainMessage);
		} catch (IOException e) {
			throw new GETException("I/O failed during GET " + filename + ". Message: " + e.getMessage());
		}
	}
	
	
	/**
	 * Perform the miniSSL handshake
	 * @param clientSocket socket used for communication
	 * @throws HandshakeException in case of an error
	 */
	public void performHandshake(Socket clientSocket) throws HandshakeException {
		session.setClientIP(clientSocket.getLocalAddress().getHostAddress());
		session.setServerIP(clientSocket.getInetAddress().getHostAddress());
		session.setLocalPort(clientSocket.getLocalPort());
		session.setRemotePort(clientSocket.getPort());
		
		// Send ClientInit
		ClientInitMessage clientInitMessage = new ClientInitMessage();
		session.setClientNonce(clientInitMessage.getNonce());
		try {
			send(clientInitMessage);
		} catch (IOException e) {
			throw new HandshakeException("I/O failed while sending clientInit. Message: " + e.getMessage());
		}
		
		// Wait for ServerInit
		ServerInitMessage serverInitMessage = null;
		try {
			serverInitMessage = receiveServerInit();
		} catch (IOException e) {
			throw new HandshakeException("I/O failed while receiving serverInit. Message: " + e.getMessage());
		}
		session.setServerNonce(serverInitMessage.getNonce());
		session.setClientAuthRequired(serverInitMessage.isClientAuthRequired());
		session.setServerCertificate(serverInitMessage.getCertificate());
		
		// Verify validity of certificate 
		try {
			CommonCrypto.verifyCertificate(session.getServerCertificate(), session.getCACertificate());
		} catch (CertificateException e) {
			//logger.error("Unable to verify the received X.509 Server Certificate: " + e.getMessage());
			throw new HandshakeException("Unable to verify the received X.509 Server Certificate: " + e.getMessage());
		} catch (InvalidKeyException e) {
			//logger.error("Invalid key for received X.509 Server Certificate: " + e.getMessage());
			throw new HandshakeException("Invalid key for received X.509 Server Certificate: " + e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			//logger.error("Invalid cipher for received X.509 Server Certificate: " + e.getMessage());
			throw new HandshakeException("Invalid cipher for received X.509 Server Certificate: " + e.getMessage());
		} catch (NoSuchProviderException e) {
			//logger.error("Invalid provider for received X.509 Server Certificate file: " + e.getMessage());
			throw new HandshakeException("Invalid provider for received X.509 Server Certificate file: " + e.getMessage());
		} catch (SignatureException e) {
			//logger.error("Invalid signature for received X.509 Server Certificate file: " + e.getMessage());
			throw new HandshakeException("Invalid signature for received X.509 Server Certificate file: " + e.getMessage());
		}
		
		// Generate 47 byte random master secret
		session.setMasterSecret(generateMasterSecret(47));
		
		// Generate two session keys, one for encryption, one for mac
		try {
			session.setEncKey(CommonCrypto.generateSessionKey(Settings.ALGORITHM_HASHING, session.getMasterSecret(), session.getClientNonce(), session.getServerNonce(), new String("00000000").getBytes(Settings.CHARSET)));
			session.setMacKey(CommonCrypto.generateSessionKey(Settings.ALGORITHM_HASHING, session.getMasterSecret(), session.getClientNonce(), session.getServerNonce(), new String("11111111").getBytes(Settings.CHARSET)));
		} catch (IOException e) {
			throw new HandshakeException ("I/O failed during generation of session keys. Message: " + e.getMessage());
		} catch (InvalidKeyException e) {
			throw new HandshakeException ("Unable to generate Session Keys. The key was invalid. Message: " + e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			throw new HandshakeException ("Unable to generate Session Keys. The specified algorithm was invalid. Message: " + e.getMessage());
		}
		
		// Generate Session hash
		try {
			session.setSecureSessionHash(CommonCrypto.generateSessionHash(Settings.ALGORITHM_HASHING, session.getMacKey(), session.getClientNonce(), session.getServerNonce(), session.getServerCertificate().getEncoded(), session.isClientAuthRequired()));
		} catch (IOException e) {
			throw new HandshakeException ("I/O failed during generation of session hash. Message: " + e.getMessage());
		} catch (InvalidKeyException e) {
			throw new HandshakeException ("Unable to generate Session Hash. The key was invalid. Message: " + e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			throw new HandshakeException ("Unable to generate Session Hash. The specified algorithm was invalid. Message: " + e.getMessage());
		} catch (CertificateEncodingException e) {
			throw new HandshakeException ("Unable to generate Session Hash. The specified Certificate has invalid encoding. Message: " + e.getMessage());
		}
		
		// Encrypt master secret with public key from verified Server certificate
		try {
			logger.debug("THE MASTER SECRET (p): " + new String(session.getMasterSecret(), Settings.CHARSET));
		} catch (UnsupportedEncodingException e) {
			logger.debug("THE MASTER SECRET (p): <INVALID ENCODING: " + Settings.CHARSET + ">");
		}

		try {
			session.setEncryptedSecret(CommonCrypto.encrypt(session.getMasterSecret(), Settings.ALGORITHM_ENCRYPTION, session.getServerCertificate().getPublicKey()));
		} catch (InvalidKeyException e) {
			try {
				throw new HandshakeException ("Unable to encrypt master secret. The key was invalid. Message: " + e.getMessage() + "\nKey: <" + new String(session.getServerCertificate().getPublicKey().getEncoded(), Settings.CHARSET) + ">");
			} catch (UnsupportedEncodingException e1) {
				throw new HandshakeException ("Unable to encrypt master secret. The key was invalid. Message: " + e.getMessage() + "\nKey: <INVALID ENCODING: " + Settings.CHARSET + ">");
			}
		} catch (NoSuchAlgorithmException e) {
			throw new HandshakeException ("Unable to encrypt master secret. Invalid Algorithm: " + Settings.ALGORITHM_ENCRYPTION + ". Message: " + e.getMessage());
		} catch (NoSuchPaddingException e) {
			throw new HandshakeException ("Unable to encrypt master secret. No such Padding for " + Settings.ALGORITHM_ENCRYPTION + ". Message: " + e.getMessage());
		} catch (IllegalBlockSizeException e) {
			throw new HandshakeException ("Unable to encrypt master secret. Illegal Block Size for Algorithm: " + Settings.ALGORITHM_ENCRYPTION + ". Message: " + e.getMessage());
		} catch (BadPaddingException e) {
			throw new HandshakeException ("Unable to encrypt master secret. Invalid padding for: " + Settings.ALGORITHM_ENCRYPTION + ". Message: " + e.getMessage());
		}
		
		// Send ClientKeyExchangeMessage to Server
		if (session.isClientAuthRequired()) {
			// mutual authentication
			try {
				byte[] sigContent = CommonCrypto.concatenateByteArray(session.getServerNonce(), session.getEncryptedSecret());
				byte[] sigContentHash = CommonCrypto.generateHash(Settings.ALGORITHM_HASHING, session.getMacKey(), sigContent);
				byte[] signature = CommonCrypto.sign(sigContentHash, Settings.ALGORITHM_ENCRYPTION, this.clientPrivateKey);
				
				ClientKeyExchangeMessage clientKeyExchangeMessage = new ClientKeyExchangeMessage(session.getEncryptedSecret(), session.getSecureSessionHash(), session.getClientCertificate(), signature);
				
				try {
					send(clientKeyExchangeMessage);
				} catch (IOException e) {
					throw new HandshakeException("I/O failed while sending clientKeyExchangeMessage. Message: " + e.getMessage());
				}
			} catch (InvalidKeyException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (NoSuchAlgorithmException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			

		} else {
			// simple authentication
			ClientKeyExchangeMessage clientKeyExchangeMessage = new ClientKeyExchangeMessage(session.getEncryptedSecret(), session.getSecureSessionHash());
			try {
				send(clientKeyExchangeMessage);
			} catch (IOException e) {
				throw new HandshakeException("I/O failed while sending clientKeyExchangeMessage. Message: " + e.getMessage());
			}
		}
		
		// Compute confirmation Hash
		try {
		if (session.isClientAuthRequired())
			session.setSecureConfirmationHash(CommonCrypto.generateConfirmationHash(Settings.ALGORITHM_HASHING, session.getMacKey(), session.getEncryptedSecret(), session.getSecureSessionHash(), session.getClientCertificate()));
		else
			session.setSecureConfirmationHash(CommonCrypto.generateConfirmationHash(Settings.ALGORITHM_HASHING, session.getMacKey(), session.getEncryptedSecret(), session.getSecureSessionHash()));
		} catch (IOException e) {
			throw new HandshakeException ("I/O failed during generation of Confirmation hash. Message: " + e.getMessage());
		} catch (InvalidKeyException e) {
			throw new HandshakeException ("Unable to generate Confirmation Hash. The key was invalid. Message: " + e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			throw new HandshakeException ("Unable to generate Confirmation Hash. The specified algorithm was invalid. Message: " + e.getMessage());
		}
		
		// Wait for ServerAuthConfirmation
		ServerAuthConfirmationMessage serverAuthConfirmationMessage = null;
		try {
			serverAuthConfirmationMessage = receiveServerAuthConfirmation();
		} catch (IOException e) {
			throw new HandshakeException("I/O failed while sending serverAuthConfirmationMessage. Message: " + e.getMessage());
		}
		
		// Compare generated confirmation Hash with confirmation Hash received from Server
		if (!CommonCrypto.isByteArrayEqual(session.getSecureConfirmationHash(), serverAuthConfirmationMessage.getConfirmationHash())) {
			throw new HandshakeException("Confirmation Information Mismatch. Confirmation Hash received from Server did not match Confirmation Hash computed by Client.");
		} else {
			logger.info("Successfully compared Auth Information. Confirmation Hash for Client matches Hash received from Server.");
		}
		
		// Validate all session information
		try {
			session.validateSession();
		} catch (SessionException e) {
			throw new HandshakeException("The Session failed to validate. Inconsistent Session Data. Message: " + e.getMessage());
		}
		logger.info("Session validated. Handshake is complete.");
	}

	/**
	 * @param args 1. destination IP, 2. destination Port, 3. Path to Clients Certificate file, 4. Path to File containing Clients private key
	 * @throws Exception 
	 */
	public static void main(String[] args) {
		if (args.length != 4) {
			System.out.println("Usage: Client <dst_ip> <dst_port> <client_cert> <private_key>");
			System.exit(1);
		}
		
		
		String destIP = args[0];
		int destPort = Integer.parseInt(args[1]);
		String clientCertPath = args[2];
		String clientPrivKeyPath = args[3];
		
		Client client = new Client(destIP, destPort, clientCertPath, clientPrivKeyPath);
		
		//Client client = new Client("127.0.0.1", 50000, "certs/minissl-client.pem", "certs/minissl-client.key.pem");
		//Client client = new Client("127.0.0.1", 50000, "certs/minissl-client.pem", "certs/minissl-client.key.pem");
		// 127.0.0.1 50000 certs/minissl-client.pem certs/minissl-client.key.pem
		// 127.0.0.1 50000 certs/rogue-client.pem certs/rogue-client.key.pem
		try {
			// start client processing (handshake & get)
			client.process();
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			System.out.println("Client Application terminated.");
			System.exit(1);
		}
	}
	
	
	/**
	 * Initialize log4j logging
	 * Clients log file in logs/client.log
	 */
	public void initLog() {
		LogSetup ls = new LogSetup("logs\\client.log", "Client", Level.ALL);
		this.logger = ls.getLogger();
	}
}
