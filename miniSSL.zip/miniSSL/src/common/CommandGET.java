package common;

import java.io.Serializable;

/**
 * GET Request Message for filename
 * @author Elias Tatros
 *
 */
public class CommandGET implements Message, Serializable {

	static final long serialVersionUID = 6507407697027811472L;
	
	public static final MessageType MESSAGE_TYPE = MessageType.CommandGET;
	private String filename;
	
	public CommandGET(String filename) {
		this.filename = filename;
	}
	
	public MessageType getType() {
		return MESSAGE_TYPE;
	}
	
	public String getFilename() {
		return this.filename;
	}
	
	@Override
	public String toString() {
		return "Type: " + MESSAGE_TYPE + ", filename: " + filename;
	}
}
