package common;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.FileUtils;

/**
 * Enrypted Message
 * @author Elias Tatros
 *
 */
public class EncryptedFileMessage implements Message, Serializable {

	private static final long serialVersionUID = 5896548750615194566L;
	public static final MessageType MESSAGE_TYPE = MessageType.EncryptedFileMessage;
	byte[] fileContents;
	byte[] IV;
	private String algorithm;
	
	/**
	 * Create encrypted Message from file using given algorithm and key
	 * @param filename
	 * @param algorithm
	 * @param key
	 * @throws IOException
	 */
	public EncryptedFileMessage(String filename, String algorithm, Key key) throws IOException {
		File baseDir = new File(Settings.SERVER_FILES);
		this.algorithm = algorithm;
		Collection<File> fileList = FileUtils.listFiles(baseDir, null, true);
		
		for (File file : fileList) {
			System.out.println("Looking for: " + filename);
			if (file.getName().equals(filename)) {
				// System.out.println("File " + file.getName() + " found. Loading Contents:");
				fileContents = Files.readAllBytes(file.toPath());
				// System.out.println(new String(fileContents, Settings.CHARSET));
				
				/* Encrypt contents AES-CBC-128 */	 
				SecretKeySpec k = new SecretKeySpec(key.getEncoded(), "AES");
				
				Cipher cipher;
				try {
					// "AES/CBC/PKCS5Padding"
					cipher = Cipher.getInstance(algorithm);
					cipher.init (Cipher.ENCRYPT_MODE, k);
					this.IV = cipher.getIV();
					byte[] encryptedContents = cipher.doFinal(this.fileContents);
					//System.out.println("---BEGIN ENCRYPTED CONTENTS---");
					// System.out.println(new String(encryptedContents, Settings.CHARSET));
					//System.out.println("---END ENCRYPTED CONTENTS---");
					this.fileContents = encryptedContents;
				} catch (NoSuchAlgorithmException e) {
					throw new IOException("Unable to encrypt file contents: " + e.getMessage());
				} catch (NoSuchPaddingException e) {
					throw new IOException("Unable to encrypt file contents: " + e.getMessage());
				} catch (InvalidKeyException e) {
					throw new IOException("Unable to encrypt file contents: " + e.getMessage());
				} catch (IllegalBlockSizeException e) {
					throw new IOException("Unable to encrypt file contents: " + e.getMessage());
				} catch (BadPaddingException e) {
					throw new IOException("Unable to encrypt file contents: " + e.getMessage());
				}
			}
		}
		
		if (this.fileContents == null) {
			throw new IOException("The file \"" + filename + "\" was not found in folder: " + Settings.SERVER_FILES);
		}
	}
	
	public String getAlgorithm() {
		return this.algorithm;
	}
	
	public MessageType getType() {
		return MESSAGE_TYPE;
	}
	
	public byte[] getEncryptedMessage() {
		return this.fileContents;
	}
	
	public byte[] getIV() {
		return this.IV;
	}
	
	@Override
	public String toString() {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("Type: " + MESSAGE_TYPE + ", algorithm: " + algorithm + ", contents:\n");
			sb.append("---BEGIN ENCRYPTED FILE CONTENTS---\n");
			sb.append(new String(fileContents, Settings.CHARSET));
			sb.append("\n---END ENCRYPTED FILE CONTENTS---\n");
			return sb.toString();
		} catch (UnsupportedEncodingException e) {
			StringBuilder sb = new StringBuilder();
			sb.append("Type: " + MESSAGE_TYPE + ", algorithm: " + algorithm + ", contents:\n");
			sb.append("---BEGIN ENCRYPTED FILE CONTENTS---\n");
			sb.append("<ENCODING " + Settings.CHARSET + " not supported.>");
			sb.append("\n---END ENCRYPTED FILE CONTENTS---\n");
			return sb.toString();
		}
	}
}
