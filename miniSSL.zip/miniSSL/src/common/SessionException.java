package common;

public class SessionException extends Exception {

	private static final long serialVersionUID = -6960900566696027788L;
	
	public SessionException(String message) {
		super(message);
	}
}
