package common;

public interface Message {
	public MessageType getType();
}
