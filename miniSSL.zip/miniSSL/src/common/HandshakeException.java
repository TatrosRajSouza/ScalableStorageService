package common;

public class HandshakeException extends Exception {

	private static final long serialVersionUID = -858364099629332986L;
	
	public HandshakeException(String message) {
		super(message);
	}

}
