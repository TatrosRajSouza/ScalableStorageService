package logging;

import java.io.IOException;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

/**
 * Sets up logging with Log4J.
 */
public class LogSetup {

	private Logger logger;
	
	public LogSetup(String logdir, String name, Level level) {
		initLog(name, logdir, level);
	}
	
	public void initLog(String name, String dir, Level level) {
		// create logger
		logger = Logger.getLogger(name);

		FileAppender fileAppender;
		try {
			PatternLayout layout = new PatternLayout( "%d{HH:mm:ss} %-5p [%t] %c: %m%n" );
			fileAppender = new FileAppender(layout, dir);
			
			logger.removeAllAppenders();
			logger.addAppender(fileAppender);
			logger.addAppender(new ConsoleAppender(layout));
			logger.setLevel(level);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Logger getLogger() {
		return this.logger;
	}
	
	public static boolean isValidLevel(String levelString) {
		boolean valid = false;
		
		if(levelString.equals(Level.ALL.toString())) {
			valid = true;
		} else if(levelString.equals(Level.DEBUG.toString())) {
			valid = true;
		} else if(levelString.equals(Level.INFO.toString())) {
			valid = true;
		} else if(levelString.equals(Level.WARN.toString())) {
			valid = true;
		} else if(levelString.equals(Level.ERROR.toString())) {
			valid = true;
		} else if(levelString.equals(Level.FATAL.toString())) {
			valid = true;
		} else if(levelString.equals(Level.OFF.toString())) {
			valid = true;
		}
		
		return valid;
	}
	
	public static String getPossibleLogLevels() {
		return "ALL | DEBUG | INFO | WARN | ERROR | FATAL | OFF";
	}
}

