This is my solution for assignment 3 of the course "Network Security".
The source code to my miniSSL implementation in JAVA 1.7, can be found under
directory "src". For easy use binary .jar executables are provided in
directory "miniSSL-jar".

Please note, that for use in JAVA, I had to convert the given private keys 
to PKCS8 in DER format. This was done with the command:
"openssl pkcs8 -topk8 -nocrypt -inform PEM -outform DER -in inputKey.key.pem -out pkcs8OutputKey.key.pem"
Other than that the certificates/keys are untouched.

Quick Start
-----------
In order for the program to function correctly the provided
directory structure must be used:
Directory		Purpose
/certs		Contains Certificates & keys
/certs/trustStore	Contains trusted CA Certificates
/clientFiles		Contains files downloaded by clients
/serverFiles		Contains files that are served by the Server

For easy use I provide 2 jar files, one for the client and one
for the server. These can be found in miniSSL-jar.

Example of how to run the Client:
java -jar Client.jar 127.0.0.1 50000 certs/minissl-client.pem certs/minissl-client.key.pem

Example of how to run the Server:
java -jar Server.jar 50000 certs/minissl-server.pem certs/minissl-server.key.pem ClientAuth payload.txt



Libraries used
---------------
I used apache commons IO library 2.4 for easier file IO and log4j 1.2.17 
for more sophisticated logging and console output.



Configuration
-------------
Some aspects of the program can be configured in Settings.java.
However, this is not tested and not recommended.
(but you can do things like changing the CA certificate here)



About the Client program (short overview)
-----------------------------------------
The client program functions as specified by the protocol given in
Assignment 3 and should implement all the "MUST" cases.

It downloads the file "payload.txt" from the server. 
This transfer is encrypted using AES-CBC-128.
The keys for this encryption and HMAC are exchanged
using RSA Authentication and Encryption, as specified 
in the protocol. Please note that certs/trustStore 
must contain Certificates of all trusted CAs.

The client then uses the encryption key to
decrypt the received file and writes it to the folder
/clientFiles. The Client program writes logs to the file /logs/client.log.
Please see source code comments for all implementation details.



About the Server program (short overview)
-----------------------------------------
The Server listens on the specified port for incoming connections.
It should implement all "MUST" cases from the assignment.
It can operate with or without Client authentication.
Files are served from the /serverFiles folder. Please make sure
payload.txt is available in this folder. The Server creates
a new Thread and Socket for every connecting client, which is of course
closed after communication is completed. Logs from these Connections
are written to logs/connection.log. The Server has a log as well, located
at logs/server.log. However all important information is in the connection log.